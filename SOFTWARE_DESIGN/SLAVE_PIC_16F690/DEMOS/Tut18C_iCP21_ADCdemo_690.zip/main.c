/********************************************************************
|     Tutorial 18C - iBoard Tiny iCP21 (PIC16F690) ADC Demo         |
 ********************************************************************
 This program shows how to use the ADC (Analog-to-Digital converter)
 pin on a PIC16F690.                     
 This tutorial will work with the Hi-Tech C compilers.              
				                                                      
 iBoard connection as follows:                   				      
    PIN   			Module                         				  
 -------------------------------------------                        
   PORTC      iCM02 - 8 LEDs Module                            
    RA2        10K Potentiometer									  

Note: 
1. RA0 & RA1: ICSP (PGD & PGC)
2. RA3: MCLR
                                                                    
**********************************************************************
|              WWW.PICCIRCUIT.COM  (C) Copyright 2012 		         |   
**********************************************************************
| This source code may only be used with PICCIRCUIT products only.   | 
| If you distribute the source code, the source code must have this  | 
| entire copyright and disclaimer notice. No other use, reproduction | 
| or distribution is permitted without written permission.			 | 
**********************************************************************
|	Program: main.c												 	 |
|	Version: 1.0													 |
|-------------------------------------------------------------------*/
#define	XTAL_FREQ	8MHZ		/* Crystal frequency in MHz */
#include <pic.h>
#include "delay.h"

unsigned char ADC_Value=0;

// ============================================================
// Configuration Bits 
// ============================================================
__CONFIG(FOSC_INTRCIO & WDTE_OFF & CP_OFF & CPD_OFF & BOREN_OFF);

/**************************************************************
                    Initialise System
**************************************************************/
void System_init(void){

	IRCF0 = 1; 			//Internal Oscillator Frequency: 8MHz
	IRCF1 = 1; 
	IRCF2 = 1; 
	ANSEL = 0b00000100; 	//Enable analog input AN2
	ANSELH = 0x00;
	TRISA = 0b00000111;		//set A3-A5 as output, A0-A2 as input
	TRISC = 0b00000000;		//set portc as output port

	ADCON0 = 0b00001001; 	//Left justified, Channel 2 (AN2), A/D converter ON
	ADCON1 = 0b00110000;	//Frc

	PORTC = 0xff;		//On portc
	DelayMs(1000);		//delay 1sec
    PORTC = 0;			//Off portc
}

/**************************************************************
                   	Main Program
**************************************************************/
void main(void){

	System_init();
	while(1){				//looping
		GO_nDONE = 1; 		//Start Conversion
		while(GO_nDONE){} 	//Wait for conversion complete
		ADC_Value = ADRESH; 	
		PORTC = ADC_Value;	//Display ADC value at portc
							
	}
}
